/*
   dado un fichero de texto plano con una serie de numero(crearlo), eliminar todos los ceros que hay en el fichero, 
   y si una linea que esta llena de ceros, hay que eliminar la linea. en este caso tenermos en el fichero el contenido 
   iguiente datos 
 */
package Punto5;


public class Cinco 
{

    public static void main(String[] args)
    {
        
        

  
        
     
    }
    
}
